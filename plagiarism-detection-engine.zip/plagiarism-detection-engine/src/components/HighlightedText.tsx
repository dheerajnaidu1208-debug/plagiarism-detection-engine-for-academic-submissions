import type { MatchSpan } from "@/lib/plagiarism";

export function HighlightedText({ text, spans }: { text: string; spans: MatchSpan[] }) {
  if (!text.trim()) return null;

  const parts: Array<{ text: string; matched: boolean }> = [];
  let cursor = 0;
  for (const s of spans) {
    if (s.start > cursor) parts.push({ text: text.slice(cursor, s.start), matched: false });
    parts.push({ text: text.slice(s.start, s.end), matched: true });
    cursor = s.end;
  }
  if (cursor < text.length) parts.push({ text: text.slice(cursor), matched: false });

  return (
    <p className="whitespace-pre-wrap text-[0.95rem] leading-7 text-foreground">
      {parts.map((p, i) =>
        p.matched ? (
          <mark key={i} className="rounded-sm bg-highlight px-0.5 text-highlight-foreground">
            {p.text}
          </mark>
        ) : (
          <span key={i}>{p.text}</span>
        ),
      )}
    </p>
  );
}
