type Props = {
  score: number;
  label: string;
  tone: "ok" | "warn" | "bad";
};

const toneVar: Record<Props["tone"], string> = {
  ok: "var(--tone-ok)",
  warn: "var(--tone-warn)",
  bad: "var(--tone-bad)",
};

export function ScoreDial({ score, label, tone }: Props) {
  const radius = 62;
  const circumference = 2 * Math.PI * radius;
  const dash = (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative h-40 w-40">
        <svg viewBox="0 0 160 160" className="h-full w-full -rotate-90">
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke="var(--color-border)"
            strokeWidth="12"
          />
          <circle
            cx="80"
            cy="80"
            r={radius}
            fill="none"
            stroke={toneVar[tone]}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference}`}
            className="transition-all duration-700 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-4xl leading-none text-foreground">{score}%</span>
          <span className="mt-1 text-xs uppercase tracking-[0.18em] text-muted-foreground">
            similarity
          </span>
        </div>
      </div>
      <span
        className="rounded-full px-4 py-1.5 text-sm font-medium"
        style={{ backgroundColor: `color-mix(in oklch, ${toneVar[tone]} 16%, transparent)`, color: toneVar[tone] }}
      >
        {label}
      </span>
    </div>
  );
}
