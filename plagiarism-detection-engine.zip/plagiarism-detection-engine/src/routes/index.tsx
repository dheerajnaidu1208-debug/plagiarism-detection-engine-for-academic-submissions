import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { analyze, verdict, type AnalysisResult, type ReferenceDoc } from "@/lib/plagiarism";
import { defaultCorpus } from "@/lib/corpus";
import { ScoreDial } from "@/components/ScoreDial";
import { HighlightedText } from "@/components/HighlightedText";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Veritas — Plagiarism Detection Engine for Academic Submissions" },
      {
        name: "description",
        content:
          "Screen student submissions for copied and paraphrased content with n-gram overlap and TF-IDF similarity scoring, with highlighted matches and source attribution.",
      },
      {
        property: "og:title",
        content: "Veritas — Plagiarism Detection Engine for Academic Submissions",
      },
      {
        property: "og:description",
        content:
          "Paste or upload an assignment and get a similarity score, matched passages and the sources they came from.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const SAMPLE = `Academic integrity refers to the ethical code and moral principles that govern scholarly work. Institutions rely on automated plagiarism detection systems that compare submitted work against large databases of publications, web pages and previously submitted assignments.

In my own view, however, the interpretation of a similarity report should always rest with a trained member of staff who understands the assignment brief and the student's prior work. Numbers alone cannot describe intent, and a report is only the beginning of a conversation.

Surveys of instructors indicate that automated screening saves between five and ten hours per course each term by narrowing attention to the passages that require judgement.`;

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-xl border border-border bg-card px-5 py-4">
      <div className="font-display text-2xl text-foreground">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</div>
    </div>
  );
}

function Index() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [running, setRunning] = useState(false);
  const [extraDocs, setExtraDocs] = useState<ReferenceDoc[]>([]);
  const [sensitivity, setSensitivity] = useState(4);
  const fileRef = useRef<HTMLInputElement>(null);
  const refFileRef = useRef<HTMLInputElement>(null);

  const corpus = useMemo(() => [...defaultCorpus, ...extraDocs], [extraDocs]);

  const run = () => {
    if (!text.trim()) return;
    setRunning(true);
    window.setTimeout(() => {
      setResult(analyze(text, corpus, { shingleSize: sensitivity }));
      setRunning(false);
    }, 350);
  };

  const readFile = async (file: File) => await file.text();

  const onSubmissionFile = async (file?: File) => {
    if (!file) return;
    setText(await readFile(file));
    setResult(null);
  };

  const onReferenceFiles = async (files: FileList | null) => {
    if (!files) return;
    const docs: ReferenceDoc[] = [];
    for (const f of Array.from(files)) {
      docs.push({
        id: `custom-${f.name}-${Date.now()}`,
        title: f.name,
        source: "Uploaded reference",
        text: await readFile(f),
      });
    }
    setExtraDocs((d) => [...d, ...docs]);
    setResult(null);
  };

  const v = result ? verdict(result.overallScore) : null;

  return (
    <div className="min-h-screen bg-background font-sans">
      <header className="border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent font-display text-lg text-accent-foreground">
              V
            </div>
            <div>
              <div className="font-display text-lg leading-tight">Veritas</div>
              <div className="text-xs opacity-70">Plagiarism Detection Engine</div>
            </div>
          </div>
          <nav className="hidden gap-6 text-sm opacity-80 md:flex">
            <a href="#check" className="hover:opacity-100">
              Check a submission
            </a>
            <a href="#how" className="hover:opacity-100">
              How it works
            </a>
            <a href="#corpus" className="hover:opacity-100">
              Reference library
            </a>
          </nav>
        </div>
      </header>

      <section className="border-b border-border bg-secondary">
        <div className="mx-auto max-w-6xl px-6 py-14">
          <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">
            Academic integrity tooling
          </p>
          <h1 className="mt-4 max-w-3xl font-display text-4xl leading-[1.1] text-foreground md:text-5xl">
            Detect copied and paraphrased content in academic submissions.
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-muted-foreground">
            Veritas compares a submission against a reference library using n-gram overlap and
            TF-IDF cosine similarity, then highlights the exact passages that match and names the
            source they came from. Detection is the last line of defence — the report supports
            human judgement, it does not replace it.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <Stat value={`${corpus.length}`} label="Reference documents" />
            <Stat value="n-gram + TF-IDF" label="Detection methods" />
            <Stat value="In-browser" label="No data leaves the device" />
          </div>
        </div>
      </section>

      <main id="check" className="mx-auto max-w-6xl px-6 py-14">
        <div className="grid gap-8 lg:grid-cols-[1.15fr_1fr]">
          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-xl text-foreground">Submission</h2>
              <div className="flex gap-2 text-sm">
                <button
                  onClick={() => {
                    setText(SAMPLE);
                    setResult(null);
                  }}
                  className="rounded-lg border border-border px-3 py-1.5 text-muted-foreground transition-colors hover:bg-secondary"
                >
                  Load sample
                </button>
                <button
                  onClick={() => fileRef.current?.click()}
                  className="rounded-lg border border-border px-3 py-1.5 text-muted-foreground transition-colors hover:bg-secondary"
                >
                  Upload .txt
                </button>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".txt,.md,text/plain"
                  className="hidden"
                  onChange={(e) => onSubmissionFile(e.target.files?.[0])}
                />
              </div>
            </div>

            <textarea
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                setResult(null);
              }}
              placeholder="Paste the student's essay or assignment here…"
              className="mt-4 h-72 w-full resize-y rounded-xl border border-input bg-background p-4 text-[0.95rem] leading-7 text-foreground outline-none transition focus:border-ring focus:ring-2 focus:ring-ring/30"
            />

            <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
              <label className="flex items-center gap-3 text-sm text-muted-foreground">
                Match length
                <input
                  type="range"
                  min={3}
                  max={8}
                  value={sensitivity}
                  onChange={(e) => {
                    setSensitivity(Number(e.target.value));
                    setResult(null);
                  }}
                  className="accent-accent"
                />
                <span className="font-medium text-foreground">{sensitivity} words</span>
              </label>
              <button
                onClick={run}
                disabled={!text.trim() || running}
                className="rounded-xl bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
              >
                {running ? "Analysing…" : "Check for plagiarism"}
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            <h2 className="font-display text-xl text-foreground">Report</h2>
            {!result && (
              <p className="mt-6 text-sm leading-7 text-muted-foreground">
                Run a check to see the similarity score, the passages that matched and where they
                came from.
              </p>
            )}
            {result && v && (
              <div className="mt-6 space-y-6">
                <ScoreDial score={result.overallScore} label={v.label} tone={v.tone} />
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="rounded-xl bg-secondary px-3 py-3">
                    <div className="font-display text-lg">{result.originalityScore}%</div>
                    <div className="text-[0.7rem] uppercase tracking-wider text-muted-foreground">
                      Original
                    </div>
                  </div>
                  <div className="rounded-xl bg-secondary px-3 py-3">
                    <div className="font-display text-lg">{result.wordCount}</div>
                    <div className="text-[0.7rem] uppercase tracking-wider text-muted-foreground">
                      Words
                    </div>
                  </div>
                  <div className="rounded-xl bg-secondary px-3 py-3">
                    <div className="font-display text-lg">{result.sources.length}</div>
                    <div className="text-[0.7rem] uppercase tracking-wider text-muted-foreground">
                      Sources
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {result.sources.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      No matching source found in the reference library.
                    </p>
                  )}
                  {result.sources.map((s) => (
                    <div key={s.doc.id} className="rounded-xl border border-border p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-sm font-medium text-foreground">{s.doc.title}</div>
                          <div className="text-xs text-muted-foreground">{s.doc.source}</div>
                        </div>
                        <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 text-xs font-medium">
                          {s.score}%
                        </span>
                      </div>
                      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                        <div
                          className="h-full rounded-full bg-accent"
                          style={{ width: `${s.score}%` }}
                        />
                      </div>
                      <ul className="mt-3 space-y-1">
                        {s.matchedPhrases.slice(0, 3).map((p) => (
                          <li key={p} className="truncate text-xs italic text-muted-foreground">
                            “…{p}…”
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {result && (
          <div className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl text-foreground">Annotated submission</h2>
              <span className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="inline-block h-3 w-6 rounded bg-highlight" /> matched passage
              </span>
            </div>
            <div className="mt-4">
              <HighlightedText text={text} spans={result.spans} />
            </div>
          </div>
        )}

        <section id="how" className="mt-16 grid gap-6 md:grid-cols-3">
          {[
            {
              t: "Shingling",
              d: "The submission is normalised, stripped of stop words and split into overlapping word n-grams so reordered sentences still match.",
            },
            {
              t: "Containment & TF-IDF",
              d: "Overlap is measured as containment against each source, blended with a TF-IDF cosine score that rewards distinctive shared terminology.",
            },
            {
              t: "Attribution",
              d: "Matched n-grams are located back in the original text so the report shows the exact passage and the source it came from.",
            },
          ].map((c) => (
            <div key={c.t} className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-display text-lg text-foreground">{c.t}</h3>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{c.d}</p>
            </div>
          ))}
        </section>

        <section id="corpus" className="mt-16 rounded-2xl border border-border bg-card p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-xl text-foreground">Reference library</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Sources the submission is compared against. Add prior submissions to widen coverage.
              </p>
            </div>
            <button
              onClick={() => refFileRef.current?.click()}
              className="rounded-lg border border-border px-4 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary"
            >
              Add reference .txt files
            </button>
            <input
              ref={refFileRef}
              type="file"
              multiple
              accept=".txt,.md,text/plain"
              className="hidden"
              onChange={(e) => onReferenceFiles(e.target.files)}
            />
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {corpus.map((d) => (
              <div key={d.id} className="rounded-xl border border-border px-4 py-3">
                <div className="text-sm font-medium text-foreground">{d.title}</div>
                <div className="text-xs text-muted-foreground">{d.source}</div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-primary py-8 text-primary-foreground">
        <div className="mx-auto max-w-6xl px-6 text-sm opacity-75">
          Veritas — a demonstration plagiarism detection engine. Similarity is evidence, not a
          verdict: always pair reports with policy, training and human review.
        </div>
      </footer>
    </div>
  );
}
