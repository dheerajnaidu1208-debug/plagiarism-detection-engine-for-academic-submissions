// Core plagiarism detection logic: n-gram shingling + Jaccard/containment
// similarity, plus TF-IDF cosine similarity. Runs entirely in the browser.

export type ReferenceDoc = {
  id: string;
  title: string;
  source: string;
  text: string;
};

export type MatchSpan = {
  start: number;
  end: number;
};

export type SourceResult = {
  doc: ReferenceDoc;
  containment: number; // 0..1 how much of the submission appears in this source
  cosine: number; // 0..1 tf-idf cosine similarity
  score: number; // blended 0..100
  matchedPhrases: string[];
};

export type AnalysisResult = {
  overallScore: number;
  originalityScore: number;
  wordCount: number;
  matchedWords: number;
  sources: SourceResult[];
  spans: MatchSpan[];
};

const STOP_WORDS = new Set(
  "a an the and or but if then than that this these those of in on at to for with by from as is are was were be been being it its into about over under not no nor so such can could should would may might will shall do does did have has had".split(
    " ",
  ),
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s']/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

function contentTokens(text: string): string[] {
  return tokenize(text).filter((t) => !STOP_WORDS.has(t));
}

function shingles(tokens: string[], n: number): string[] {
  const out: string[] = [];
  for (let i = 0; i + n <= tokens.length; i++) out.push(tokens.slice(i, i + n).join(" "));
  return out;
}

function termFreq(tokens: string[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const t of tokens) m.set(t, (m.get(t) ?? 0) + 1);
  return m;
}

function cosineTfIdf(
  a: Map<string, number>,
  b: Map<string, number>,
  idf: Map<string, number>,
): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  const keys = new Set([...a.keys(), ...b.keys()]);
  for (const k of keys) {
    const w = idf.get(k) ?? 1;
    const va = (a.get(k) ?? 0) * w;
    const vb = (b.get(k) ?? 0) * w;
    dot += va * vb;
    na += va * va;
    nb += vb * vb;
  }
  if (!na || !nb) return 0;
  return dot / Math.sqrt(na * nb);
}

/** Locate character ranges in the original text for each matched shingle. */
function locateSpans(text: string, phrases: string[]): MatchSpan[] {
  const lower = text.toLowerCase();
  const spans: MatchSpan[] = [];
  for (const phrase of phrases) {
    const words = phrase.split(" ");
    // Build a loose regex allowing stop words / punctuation between content words.
    const pattern = words
      .map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join("(?:[^a-z0-9]+(?:[a-z']+[^a-z0-9]+)??)");
    let re: RegExp;
    try {
      re = new RegExp(pattern, "g");
    } catch {
      continue;
    }
    let m: RegExpExecArray | null;
    while ((m = re.exec(lower)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length });
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  }
  return mergeSpans(spans);
}

export function mergeSpans(spans: MatchSpan[]): MatchSpan[] {
  const sorted = [...spans].sort((a, b) => a.start - b.start);
  const out: MatchSpan[] = [];
  for (const s of sorted) {
    const last = out[out.length - 1];
    if (last && s.start <= last.end + 1) last.end = Math.max(last.end, s.end);
    else out.push({ ...s });
  }
  return out;
}


export type AnalyzeOptions = {
  shingleSize?: number;
  threshold?: number; // minimum blended score (0..100) to report a source
};

export function analyze(
  submission: string,
  corpus: ReferenceDoc[],
  options: AnalyzeOptions = {},
): AnalysisResult {
  const n = options.shingleSize ?? 4;
  const threshold = options.threshold ?? 5;

  const subTokens = contentTokens(submission);
  const subShingles = shingles(subTokens, n);
  const subSet = new Set(subShingles);
  const subTf = termFreq(subTokens);

  // IDF over the corpus + submission
  const df = new Map<string, number>();
  const docsTokens = corpus.map((d) => contentTokens(d.text));
  const allDocs = [subTokens, ...docsTokens];
  for (const toks of allDocs) {
    for (const t of new Set(toks)) df.set(t, (df.get(t) ?? 0) + 1);
  }
  const N = allDocs.length;
  const idf = new Map<string, number>();
  for (const [t, c] of df) idf.set(t, Math.log(1 + N / c));

  const allMatched = new Set<string>();
  const sources: SourceResult[] = [];

  corpus.forEach((doc, i) => {
    const docToks = docsTokens[i] ?? [];

    const docShingleSet = new Set(shingles(docToks, n));
    const matched: string[] = [];
    for (const s of subSet) if (docShingleSet.has(s)) matched.push(s);

    const containment = subSet.size ? matched.length / subSet.size : 0;
    const cosine = cosineTfIdf(subTf, termFreq(docToks), idf);
    const score = Math.round(Math.min(100, (containment * 0.75 + cosine * 0.25) * 100));

    if (score >= threshold && matched.length > 0) {
      matched.forEach((m) => allMatched.add(m));
      sources.push({
        doc,
        containment,
        cosine,
        score,
        matchedPhrases: matched.sort((a, b) => b.length - a.length).slice(0, 8),
      });
    }
  });

  sources.sort((a, b) => b.score - a.score);

  const spans = locateSpans(submission, [...allMatched]);
  const matchedChars = spans.reduce((acc, s) => acc + (s.end - s.start), 0);
  const wordCount = tokenize(submission).length;
  const matchedWords = Math.min(
    wordCount,
    Math.round(matchedChars / Math.max(1, submission.length / Math.max(1, wordCount))),
  );

  const overallScore = subSet.size
    ? Math.round(Math.min(100, (allMatched.size / subSet.size) * 100))
    : 0;

  return {
    overallScore,
    originalityScore: 100 - overallScore,
    wordCount,
    matchedWords,
    sources,
    spans,
  };
}

export function verdict(score: number): { label: string; tone: "ok" | "warn" | "bad" } {
  if (score < 15) return { label: "Likely original", tone: "ok" };
  if (score < 35) return { label: "Needs review", tone: "warn" };
  return { label: "High similarity", tone: "bad" };
}
