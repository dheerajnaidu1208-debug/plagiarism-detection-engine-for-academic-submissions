import type { ReferenceDoc } from "./plagiarism";

/**
 * Built-in reference corpus. In a production deployment this would be replaced
 * by an indexed database of prior submissions, journals and web crawls.
 */
export const defaultCorpus: ReferenceDoc[] = [
  {
    id: "ref-1",
    title: "Academic Integrity in the Digital Age",
    source: "Journal of Higher Education Policy, 2021",
    text: `Academic integrity refers to the ethical code and moral principles that govern scholarly work. In the digital age, the availability of vast online resources has made it easier for students to copy or paraphrase content without attribution. Institutions therefore rely on automated plagiarism detection systems that compare submitted work against large databases of publications, web pages and previously submitted assignments. These systems compute similarity scores using techniques such as fingerprinting, n-gram overlap and vector space models. A high similarity score does not by itself prove misconduct; human review remains essential to interpret the result in context.`,
  },
  {
    id: "ref-2",
    title: "Natural Language Processing Methods for Text Reuse Detection",
    source: "Proceedings of the Computational Linguistics Workshop, 2019",
    text: `Text reuse detection combines lexical and semantic methods. Lexical approaches rely on character or word n-gram shingling, hashing and inverted indexes to find exact and near-exact overlap efficiently. Semantic approaches use word embeddings, sentence transformers and latent semantic analysis to capture paraphrase where surface wording differs. Term frequency inverse document frequency weighting reduces the influence of common words and highlights distinctive terminology. Evaluation typically reports precision, recall and the harmonic mean, measured on benchmark corpora of artificially obfuscated passages.`,
  },
  {
    id: "ref-3",
    title: "Machine Learning Infrastructure for Educational Platforms",
    source: "Technical Report, Institute of Learning Systems, 2022",
    text: `Deploying a detection engine at institutional scale requires careful capacity planning. Document ingestion pipelines must handle bursts around assessment deadlines, so horizontally scalable application servers and object storage for raw submissions are recommended. A relational database stores metadata while an inverted index supports fast similarity queries. Graphics processing units accelerate transformer based paraphrase models. Retention policies, encryption at rest and access controls protect student data and support compliance with privacy regulation.`,
  },
  {
    id: "ref-4",
    title: "Detecting Machine Generated Text in Student Work",
    source: "Emerging Trends in Assessment, 2024",
    text: `The rapid adoption of large language models has introduced a new category of academic misconduct in which submissions are generated rather than copied. Detectors for machine generated text examine statistical signals such as token perplexity, burstiness and the distribution of function words. Watermarking schemes embed imperceptible patterns during generation that can later be verified. Accuracy remains limited and false positives disproportionately affect students writing in a second language, so such tools should inform rather than determine academic decisions.`,
  },
  {
    id: "ref-5",
    title: "Reducing Faculty Workload Through Automated Screening",
    source: "Teaching and Learning Quarterly, 2020",
    text: `Manual review of written assignments is time consuming. Surveys of instructors indicate that automated screening saves between five and ten hours per course each term by narrowing attention to the passages that require judgement. Beyond efficiency, the presence of a detection process acts as a deterrent: students who know their work will be screened are markedly less likely to submit unoriginal content. Effective programmes pair the technology with clear policy, transparent reporting to students and training for staff who interpret the reports.`,
  },
  {
    id: "ref-6",
    title: "Paraphrase Obfuscation and Evasion Techniques",
    source: "Security and Integrity in Education, 2023",
    text: `Students seeking to evade detection employ synonym substitution, sentence reordering, translation round trips and the insertion of invisible characters. Character level normalisation and homoglyph mapping defeat the simplest of these attacks. Reordering is countered by comparing bags of shingles rather than sequences, while translation obfuscation requires cross language retrieval using multilingual embeddings. An engine that layers several independent signals is substantially harder to evade than one relying on exact string matching alone.`,
  },
];
